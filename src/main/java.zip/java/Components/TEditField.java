package Components;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class TEditField extends TLabel{
    private String str;
    private boolean onFocus;
    public TEditField(int x, int y, int width, int height, String content, Font font){
        super(x,y,width,height,content,font);
        this.str = content;
        this.onFocus = false;
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(onFocus){
                    if(str.length()>0&&e.getKeyCode()==KeyEvent.VK_BACK_SPACE){
                        str = str.substring(0,str.length()-1);
                        setContent(str);
                        repaint();
                    }
                    if(e.getKeyCode()==110||e.getKeyCode()==KeyEvent.VK_PERIOD){
                        str+='.';
                        setContent(str);
                        repaint();
                    }
                    if((e.getKeyCode()>=0x0030&&e.getKeyCode()<=0x0039)){
                        str+=(char)(e.getKeyCode());
                        setContent(str);
                        repaint();
                    }
                    if((e.getKeyCode()>=0x0060&&e.getKeyCode()<=0x0069)){
                        str+=(char)(e.getKeyCode()-0x0030);
                        setContent(str);
                        repaint();
                    }
                }
            }
        });
    }

    public boolean isOnFocus() {
        return onFocus;
    }
    public void setOnFocus(boolean onFocus) {
        this.onFocus = onFocus;
    }
}
