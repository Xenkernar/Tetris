package Components;

import java.io.IOException;

@FunctionalInterface
public interface Action {
    public abstract void action() throws IOException;
}
