package Components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Timer;
import java.util.TimerTask;

public class TSwitch extends JPanel {
    private boolean on;
    private boolean changeable;
    private int LeftTopX;
    private int opacity;
    public TSwitch(int x, int y, int width, int height){
        setPreferredSize(new Dimension(width,height));
        setOpaque(true);
        setBounds(x,y,width,height);
        on =false;
        changeable=true;
        LeftTopX = 5;
        opacity = 50;
        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if(e.getButton()==MouseEvent.BUTTON1&& 0<=e.getX()&&e.getX()<=width&&0<=e.getY()&&e.getY()<=height){
                    turn();
                }
            }
        });
    }
    @Override
    public int getWidth() {
        return getPreferredSize().width;
    }
    @Override
    public int getHeight() {
        return getPreferredSize().height;
    }

    @Override
    public void paint(Graphics g) {
        setBackground(new Color(9, 145, 244, 128));
        g.clearRect(0,0,getWidth(),getHeight());
        super.paint(g);
        g.setColor(new Color(79, 83, 247));
        g.fillRect(0,0,5,getHeight());
        g.fillRect(getWidth()-5,0,5,getHeight());
        g.setColor(new Color(0, 255, 255, opacity));
        g.fillRoundRect(LeftTopX,0,(getWidth()-10)/2,getHeight(),5,5);

    }

    public boolean isOn() {
        return on;
    }
    public void setOn(boolean on){
        this.on = on;
        if(!on){
            LeftTopX = 5;
            opacity = 50;
        }else{
            LeftTopX = getWidth() / 2;
            opacity = 255;
        }
    }
    public void turn() {
        if(changeable){
            try {
                displayAnimation();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            this.on = !on;
        }
    }
    private void displayAnimation() throws InterruptedException {
            if(!on){
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        java.util.Timer timer = new java.util.Timer();
                        timer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                changeable = false;
                                LeftTopX++;
                                if (opacity < 255) {
                                    opacity += 3;
                                }
                                TSwitch.super.repaint();
                                if (LeftTopX >= getWidth() / 2) {
                                    timer.cancel();
                                    changeable =true;
                                }
                            }
                        },0,5);
                    }
                }).start();
            }else {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Timer timer = new Timer();
                        timer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                changeable = false;
                                LeftTopX--;
                                if(opacity>50){
                                    opacity-=3;
                                }
                                TSwitch.super.repaint();
                                if(LeftTopX<=5){
                                    timer.cancel();
                                    changeable = true;
                                }
                            }
                        },0,5);
                    }
                }).start();
            }
    }
}
