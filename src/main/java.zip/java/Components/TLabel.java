package Components;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class TLabel extends JPanel {
    public static final int CENTER = 0;
    public static final int LEFT = 1;
    public static final int TOP = 2;
    private int horizontalAlignment;
    private int verticalAlignment;
    private Font font;



    private String content;
    private boolean autoFeed;
    public TLabel(int x, int y, int width, int height, String content, Font font){
        setBackground(new Color(9, 145, 244, 128));
        setPreferredSize(new Dimension(width,height));
        setOpaque(true);
        setBounds(x,y,width,height);
        this.content = content;
        this.font = font;
        horizontalAlignment = CENTER;
        verticalAlignment = CENTER;
        autoFeed=true;
    }
    public void setHorizontalAlignment(int alignment){
        this.horizontalAlignment = alignment;
    }
    public void setVerticalAlignment(int alignment){
        this.verticalAlignment = alignment;
    }
    @Override
    public int getWidth() {
        return getPreferredSize().width;
    }
    @Override
    public int getHeight() {
        return getPreferredSize().height;
    }
    public void setContent(String content){
        this.content = content;
    }
    public String getContent() {
        return content;
    }
    public void setAutoFeed(boolean autoFeed) {
        this.autoFeed = autoFeed;
    }

    @Override
    public void paint(Graphics g) {

        g.clearRect(0,0,getWidth(),getHeight());
        super.paint(g);
        g.setColor(Color.cyan);
        g.setFont(font);
        g.fillRect(0,0,5,getHeight());
        g.fillRect(getWidth()-5,0,5,getHeight());
        int textWidth = g.getFontMetrics().stringWidth(content);
        int textHeight = font.getSize();
        if(content.equals("")){
            return;
        }
        if(!autoFeed){
            int drawX = horizontalAlignment==CENTER?(getWidth()-textWidth)/2:8;
            int drawY = verticalAlignment==CENTER?(getHeight()-textHeight)/2+textHeight:textHeight;
            drawY-=textHeight/5;
            g.drawString(content,drawX,drawY);
        }
        else{
            char[] chars = content.toCharArray();
            int rows = 1;
            int curWidth = 8;
            int charWidth;
            ArrayList<Integer> colNums=new ArrayList<>();
            ArrayList<Integer> colWidths=new ArrayList<>();
            for (int i = 0; i < chars.length; i++) {
                charWidth = g.getFontMetrics().charWidth(chars[i]);
                curWidth+=charWidth;
                if(curWidth>getWidth()-8||chars[i]=='\n'||i==chars.length-1){
                    if(i!=chars.length-1){
                        colNums.add(i);
                        colWidths.add(curWidth-charWidth-8);
                        curWidth = 8+(chars[i]!='\n'?charWidth:0);
                        rows++;
                    }else{
                        colNums.add(i+1);
                        colWidths.add(curWidth-8);
                        curWidth = 8+(chars[i]!='\n'?charWidth:0);
                    }
                }
            }

            int drawY = verticalAlignment==CENTER?(getHeight()-textHeight*rows)/2+textHeight:textHeight;
            drawY-=textHeight/5;
            for (int i = 0; i < rows; i++) {
                int drawX = horizontalAlignment==CENTER?(getWidth()-colWidths.get(i))/2:8;
                g.drawString(content.substring(i!=0?colNums.get(i-1):0,colNums.get(i)),drawX,drawY);
                drawY+=textHeight;
            }
        }
    }
}
