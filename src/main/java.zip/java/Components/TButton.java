package Components;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;

public class TButton extends TLabel{
    private boolean onFocus;
    public TButton(int x, int y, int width, int height, String content, Font font){
        super(x,y,width,height,content,font);
        onFocus=false;
    }

    public boolean isOnFocus() {
        return onFocus;
    }
    public void setOnFocus(boolean onFocus) {
        this.onFocus = onFocus;
    }
    public void setAction(Action action){
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(onFocus&&e.getKeyCode()==KeyEvent.VK_ENTER){
                    try {
                        action.action();
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        });
    }
}
