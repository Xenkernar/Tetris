package Window;

import Components.Action;
import Components.TButton;
import Components.TLabel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class TDialog extends JFrame {
    private final int GAP = 15;
    private final int BUTTON_HEIGHT=44;
    private final int BUTTON_WIDTH = 307;
    private final int DIALOG_WIDTH = 337;
    private final int DIALOG_HEIGHT = 400;
    private JPanel panel;
    private TButton[] buttons;
    private int selected_index;
    private int pre_button_index;
    public TDialog(String query, String[] buttonTexts){
        setLayout(null);
        setUndecorated(true);
        setBackground(new Color(0,0,0,0));
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-DIALOG_WIDTH)/2,(screenSize.height-DIALOG_HEIGHT)/2,DIALOG_WIDTH,DIALOG_HEIGHT-120);
        panel = new JPanel();
        panel.setPreferredSize(new Dimension(DIALOG_WIDTH,DIALOG_HEIGHT));
        panel.setBounds(0,0,DIALOG_WIDTH,DIALOG_HEIGHT);
        panel.setOpaque(false);
        panel.setLayout(null);
        panel.add(new TLabel(10,10,DIALOG_WIDTH-20,DIALOG_HEIGHT/2,query,ConstructUtil.getSpecificFont(35,ConstructUtil.ANATEVKA)));
        this.buttons = new TButton[buttonTexts.length];
        for (int i = 0; i < buttons.length; i++) {
            buttons[i] = new TButton(
                    (i+1)*GAP-5+(BUTTON_WIDTH*28/55+10)*i,
                    (DIALOG_HEIGHT/2+GAP+10),
                    BUTTON_WIDTH*28/55 -20,BUTTON_HEIGHT ,
                    buttonTexts[i], ConstructUtil.getSpecificFont(BUTTON_HEIGHT * 2 / 5, ConstructUtil.CAI978)
            );
            panel.add(buttons[i]);
        }
        selected_index = 0;
        pre_button_index = 0;
        this.buttons[0].setOnFocus(true);
        panel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode()==KeyEvent.VK_LEFT){
                    buttons[pre_button_index].setOnFocus(false);
                    selected_index = (selected_index+(buttons.length-1))%buttons.length;
                    buttons[selected_index].setOnFocus(true);
                    pre_button_index = selected_index;
                    repaint();
                }
                if(e.getKeyCode()==KeyEvent.VK_RIGHT){
                    buttons[pre_button_index].setOnFocus(false);
                    selected_index = (selected_index+1)%buttons.length;
                    buttons[selected_index].setOnFocus(true);
                    pre_button_index = selected_index;
                    repaint();
                }
            }
        });
        add(panel);
        addKeyListener(panel.getKeyListeners()[0]);
    }
    public void setActions(Action[] actions){
        for (int i = 0; i < actions.length; i++) {
            buttons[i].setAction(actions[i]);
            panel.addKeyListener(buttons[i].getKeyListeners()[0]);
            addKeyListener(buttons[i].getKeyListeners()[0]);
        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.setColor(Color.WHITE);
        g.fillRect(buttons[selected_index].getX()-7, buttons[selected_index].getY()-7, 20, 4);
        g.fillRect(buttons[selected_index].getX()-7, buttons[selected_index].getY()-7, 4, 20);
        g.fillRect(buttons[selected_index].getX()+buttons[selected_index].getWidth()+7-20, buttons[selected_index].getY()-7, 20, 4);
        g.fillRect(buttons[selected_index].getX()+buttons[selected_index].getWidth()+7-4, buttons[selected_index].getY()-7, 4,20);
        g.fillRect(buttons[selected_index].getX()-7, buttons[selected_index].getY()+buttons[selected_index].getHeight()+7-20, 4, 20);
        g.fillRect(buttons[selected_index].getX()-7, buttons[selected_index].getY()+buttons[selected_index].getHeight()+7-4, 20, 4);
        g.fillRect(buttons[selected_index].getX()+buttons[selected_index].getWidth()+7-4, buttons[selected_index].getY()+buttons[selected_index].getHeight()+7-20, 4, 20);
        g.fillRect(buttons[selected_index].getX()+buttons[selected_index].getWidth()+7-20, buttons[selected_index].getY()+buttons[selected_index].getHeight()+7-4, 20,4);
    }
}
