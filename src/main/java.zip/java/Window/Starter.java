package Window;

import Components.Action;
import Tetriss.AudioPlayer;

import java.awt.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;


import static Tetriss.Configuration.*;


public class Starter {
    static {
        loadConfiguration();
    }
    private static MainFrame window;
    private static TMenu mainMenu;
    private static TMenu playMenu;
    private static TInputBox inputBox;
    private static void initMainMenu(){
        mainMenu = new TMenu(332,435,true,0,new String[]{ "PLAY", "SETTING", "EXIT"});
        mainMenu.setActions(new Action[]{
                ()->{//PLAY ACTION
                    window.remove(mainMenu);
                    window.removeAllKeyListeners(mainMenu);
                    window.add(playMenu);
                    window.addAllKeyListeners(playMenu);
                    window.repaint();
                },
                ()-> {//SETTING ACTION
                    new SettingWindow().setVisible(true);
                },
                ()-> {
                    window.dispose();
                    AudioPlayer.close();
                    System.exit(0);
                }//EXIT ACTION
        });
    }
    private static void initPlayMenu(){
        playMenu = new TMenu(332,435,true,0,new String[]{ "SINGLE", "PVP", "BACK"});
        playMenu.setActions(new Action[]{
                ()->{//选择single,单人游戏
                    SinglePlayWindow singlePlayWindow = new SinglePlayWindow();
                    singlePlayWindow.start();
                    singlePlayWindow.setWindowCloseAction(() -> {
                        window.addAllKeyListeners(playMenu);
                        window.setVisible(true);
                    });
                    window.removeAllKeyListeners(playMenu);
                    window.setVisible(false);

                },
                ()->{//选择PVP,双人PK
                    window.remove(playMenu);
                    window.removeAllKeyListeners(playMenu);
                    window.add(inputBox);
                    window.addAllKeyListeners(inputBox);
                    window.repaint();

                },
                ()->{//选择back，返回上一级
                    window.remove(playMenu);
                    window.removeAllKeyListeners(playMenu);
                    window.add(mainMenu);
                    window.addAllKeyListeners(mainMenu);
                    window.repaint();
                }
        });
    }
    private static void initInputBox(){
        inputBox = new TInputBox(332,435,"127.0.0.1",new String[]{"CONNECT","BACK"});
        inputBox.setActions(new Action[]{
                ()->{
                    if("127.0.0.1".equals(inputBox.getContent())){//连接回环地址，线下PK
                        OffLinePVPWindow offLinePVPWindow = new OffLinePVPWindow();
                        offLinePVPWindow.start();
                        offLinePVPWindow.setWindowCloseAction(()->{
                            window.setVisible(true);
                            window.addAllKeyListeners(inputBox);
                        });
                        window.setVisible(false);
                        window.removeAllKeyListeners(inputBox);

                    }else{//发送PK请求
                        new Thread(() -> {
                            try {
                                sendRequest(inputBox.getContent());
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        }).start();
                    }
                },
                ()->{
                    window.remove(inputBox);
                    window.removeAllKeyListeners(inputBox);
                    window.add(playMenu);
                    window.addAllKeyListeners(playMenu);
                    window.repaint();
                }
        });
    }
    private static void startListenRequest(){
        new Thread(() -> {
            ServerSocket serverSocket = null;
            try {
                serverSocket = new ServerSocket(20023);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            while (true) {
                Socket connectionSocket = null;
                try {
                    connectionSocket = serverSocket.accept();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                Socket finalConnectionSocket = connectionSocket;
                new Thread(() -> {
                    try {
                        BufferedReader inFromClient = new BufferedReader(new InputStreamReader(finalConnectionSocket.getInputStream()));
                        DataOutputStream outToClient = new DataOutputStream(finalConnectionSocket.getOutputStream());
                        int clientPort = Integer.parseInt(inFromClient.readLine());
                        String clientIP = finalConnectionSocket.getInetAddress().getHostAddress();

                        TDialog dialog = new TDialog("Received an invitation from\n" + clientIP + "\nAccept it?", new String[]{"ACCEPT", "REJECT"});
                        dialog.setActions(new Action[]{
                                ()->{
                                    int serverUDPPort = 20025;
                                    outToClient.writeBytes(serverUDPPort+"\n");
                                    OnLinePVPWindow onLinePVPWindow = new OnLinePVPWindow(clientIP,clientPort,serverUDPPort);
                                    onLinePVPWindow.getSpecifiedTetris().receiveBlocks(inFromClient);
                                    onLinePVPWindow.getSpecifiedTetris().sendBlocks(outToClient);
                                    finalConnectionSocket.shutdownOutput();
                                    onLinePVPWindow.getSpecifiedTetris().mixBlocks();
                                    onLinePVPWindow.start();
                                    onLinePVPWindow.setWindowCloseAction(()->{
                                        window.setVisible(true);
                                    });
                                    finalConnectionSocket.close();
                                    dialog.dispose();
                                    window.setVisible(false);
                                },
                                ()->{
                                    outToClient.writeBytes(0+"\n");
                                    dialog.dispose();
                                }
                        });
                        dialog.setVisible(true);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }).start();
            }
        }).start();
    }
    private static void sendRequest(String serverIP) throws IOException {
        String serverUDPPort;
        Socket clientSocket = new Socket(serverIP, 20023);
        DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        int clientUDPPort = 20024;
        outToServer.writeBytes(clientUDPPort + "\n");
        serverUDPPort = inFromServer.readLine();
        if(!serverUDPPort.equals("0")){
            OnLinePVPWindow onLinePVPWindow = new OnLinePVPWindow(serverIP,Integer.parseInt(serverUDPPort),clientUDPPort);
            onLinePVPWindow.getSpecifiedTetris().sendBlocks(outToServer);
            clientSocket.shutdownOutput();
            onLinePVPWindow.getSpecifiedTetris().receiveBlocks(inFromServer);
            onLinePVPWindow.getSpecifiedTetris().mixBlocks();
            onLinePVPWindow.start();
            onLinePVPWindow.setWindowCloseAction(()->{
                window.setVisible(true);
            });
            window.setVisible(false);
        }
        else{
            System.out.println("对方拒绝了你的邀请");
        }
        clientSocket.close();
    }
    public static void main(String[] args) throws IOException {
        startListenRequest();
        AudioPlayer.prePlay();
        window  = new MainFrame();
        Dimension dimension =  new Dimension(MAINWINDOW_WIDTH,MAINWINDOW_HEIGHT);
        Dimension screen =  Toolkit.getDefaultToolkit().getScreenSize();
        window.setBounds((screen.width-MAINWINDOW_WIDTH)/2,(screen.height-MAINWINDOW_HEIGHT)/2,dimension.width,dimension.height);
        window.setUndecorated(true);
        window.setBackground(new Color(0,0,0,0));
        window.setLayout(null);
        initMainMenu();
        initPlayMenu();
        initInputBox();
        window.add(mainMenu);
        window.addAllKeyListeners(mainMenu);
        window.setVisible(true);
    }
}
