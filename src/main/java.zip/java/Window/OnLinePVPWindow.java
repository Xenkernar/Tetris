package Window;

import Components.Action;
import Tetriss.BlockType;
import Tetriss.DisplayOnlyTetris;
import Tetriss.SpecifiedTetris;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.SocketException;
import java.util.ArrayList;

import static Tetriss.Configuration.TETRIS_PANEL_HEIGHT;
import static Tetriss.Configuration.TETRIS_PANEL_WIDTH;

public class OnLinePVPWindow {
    private JFrame window;
    private SpecifiedTetris specifiedTetris;
    private DisplayOnlyTetris displayOnlyTetris;
    private String opponentIP;
    private int opponentPort;
    public OnLinePVPWindow(String opponentIP ,int opponentPort,int receiveProgressPort) throws SocketException {
        window = new JFrame("Tetris : ONLINE PVP");
        ArrayList<BlockType> arr =  ConstructUtil.getRandomBlocks();
        specifiedTetris = new SpecifiedTetris(1,arr);
        displayOnlyTetris = new DisplayOnlyTetris(receiveProgressPort);
        this.opponentPort = opponentPort;
        this.opponentIP = opponentIP;
        BackgroundPanel backgroundPanel =  new BackgroundPanel(702,430);
        backgroundPanel.setLayout(null);
        backgroundPanel.add(specifiedTetris.getTetrisPanel());
        backgroundPanel.add(displayOnlyTetris.getTetrisPanel());

        window.add(backgroundPanel);
        specifiedTetris.getTetrisPanel().setBounds(10,10,TETRIS_PANEL_WIDTH+10,TETRIS_PANEL_HEIGHT+10);
        displayOnlyTetris.getTetrisPanel().setBounds(TETRIS_PANEL_WIDTH+20,10,TETRIS_PANEL_WIDTH+10,TETRIS_PANEL_HEIGHT+10);
        window.pack();
        window.setLocation(
                (Toolkit.getDefaultToolkit().getScreenSize().width - window.getWidth()) / 2,
                (Toolkit.getDefaultToolkit().getScreenSize().height - window.getHeight()) / 2
        );
        window.setResizable(true);
        window.addKeyListener(specifiedTetris.getKeyListener());
    }
    public void start() throws IOException {
        window.setVisible(true);
        specifiedTetris.start();
        specifiedTetris.sendGameProgress(opponentIP,opponentPort);
        displayOnlyTetris.reveiveGameProgress();
    }

    public SpecifiedTetris getSpecifiedTetris() {
        return specifiedTetris;
    }

    public void setWindowCloseAction(Action action){
        window.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    action.action();
                    window.dispose();
                    specifiedTetris=null;
                    displayOnlyTetris=null;
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
    }
}
