package Window;

import Tetriss.BlockType;


import java.awt.*;
import java.io.*;
import java.util.ArrayList;

public class ConstructUtil {
    private static final String FONT_PATH = "src\\main\\java\\resources\\";
    public static final String CAI978 = "204-CAI978.ttf";
    public static final String ANATEVKA = "Anatevka.otf";

    private ConstructUtil(){}
    public static Font getSpecificFont(int size,String fontName){
        InputStream is = null;
        Font baseTTF = null;
        try {
            is = new BufferedInputStream(new FileInputStream(FONT_PATH+fontName));
            baseTTF = Font.createFont(Font.TRUETYPE_FONT, is);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (FontFormatException e) {
            throw new RuntimeException(e);
        }
        return baseTTF.deriveFont(Font.PLAIN,size);
    }
    public static ArrayList<BlockType> getRandomBlocks(){
        ArrayList<BlockType> res = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            res.add(BlockType.values()[(int)(Math.random()*7)+1]);
        }
        return res;
    }
}
