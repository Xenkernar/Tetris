package Window;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import static Tetriss.Configuration.MAINWINDOW_HEIGHT;
import static Tetriss.Configuration.MAINWINDOW_WIDTH;

public class MainFrame extends JFrame {
    private BufferedImage image;
    MainFrame() throws IOException {
        image = ImageIO.read(new File("src\\main\\java\\resources\\Tetris.png"));
    }
    @Override
    public void paint(Graphics g) {
        g.drawImage(image,0,0,MAINWINDOW_WIDTH,MAINWINDOW_HEIGHT,null);
        super.paintComponents(g);
    }
    public void removeAllKeyListeners(Component comp){
        for(KeyListener kl: comp.getKeyListeners()){
            removeKeyListener(kl);
        }
    }
    public void addAllKeyListeners(Component comp){
        for(KeyListener kl: comp.getKeyListeners()){
            addKeyListener(kl);
        }
    }
}