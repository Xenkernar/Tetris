package Window;

import Components.Action;
import Tetriss.AudioPlayer;
import Tetriss.BlockType;
import Tetriss.RandomTetris;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;

import static Tetriss.Configuration.TETRIS_PANEL_HEIGHT;
import static Tetriss.Configuration.TETRIS_PANEL_WIDTH;

public class SinglePlayWindow  {
    private JFrame window;
    private RandomTetris tetris;
    SinglePlayWindow(){
        window = new JFrame("Tetris : Single Player");
        ArrayList<BlockType> arr =new ArrayList<>();
        tetris = new RandomTetris(1,true);
        BackgroundPanel backgroundPanel =  new BackgroundPanel(360,430);
        backgroundPanel.setLayout(null);
        backgroundPanel.add(tetris.getTetrisPanel());
        window.add(backgroundPanel);
        tetris.getTetrisPanel().setBounds(10,10,TETRIS_PANEL_WIDTH+10,TETRIS_PANEL_HEIGHT+10);
        window.pack();
        window.setLocation(
                (Toolkit.getDefaultToolkit().getScreenSize().width - window.getWidth()) / 2,
                (Toolkit.getDefaultToolkit().getScreenSize().height - window.getHeight()) / 2
        );
        window.setResizable(false);
        window.addKeyListener(tetris.getKeyListener());

        final boolean[] isPaused = {false};
        window.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
                    if(!isPaused[0]){
                        tetris.pauseGame();
                        window.removeKeyListener(tetris.getKeyListener());
                        isPaused[0] = true;
                    }else{
                        tetris.continueGame();
                        window.addKeyListener(tetris.getKeyListener());
                        isPaused[0] = false;
                    }
                }
            }
        });
    }
    public void start(){
        window.setVisible(true);
        tetris.start();
    }
    public void setWindowCloseAction(Action action){
        window.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                try {
                    action.action();
                    window.dispose();
                    tetris=null;
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
    }
}
