package Window;


import Components.TEditField;
import Components.TLabel;
import Components.TSwitch;
import Tetriss.BlockType;
import Tetriss.Configuration;
import Tetriss.Movement;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;


public class SettingWindow extends JFrame {


    private class SetPlayerKeyMapPanel extends JPanel{
        private class KeyCollector extends TLabel{
            public static HashMap<Integer,String> keyNameMap;
            static {
                keyNameMap = new HashMap<>();
                Field[] fields = KeyEvent.class.getFields();
                for (Field field : fields) {
                    if (Modifier.isStatic(field.getModifiers()) && field.getType() == int.class && field.getName().startsWith("VK_")) {
                        try {
                            keyNameMap.put(field.getInt(null), field.getName().substring(3));
                        } catch (IllegalAccessException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
            private boolean onFocus;
            private int maskOpacity;
            private int sign;
            private Timer timer;
            KeyCollector(int x, int y, String keyName, int player_code, Movement movement){
                super(x,y,150,40,keyName,ConstructUtil.getSpecificFont(17,ConstructUtil.CAI978));
                onFocus = false;
                maskOpacity = 0;
                sign = 1;


                addKeyListener(new KeyAdapter() {
                    @Override
                    public void keyPressed(KeyEvent e) {
                        if(onFocus){
                            setContent(keyNameMap.get(e.getKeyCode()));
                            ceaseAnimation();
                            Configuration.setPlayerKey(player_code,movement,e.getKeyCode());
                            onFocus = false;
                            repaint();
                        }
                    }
                });
            }

            @Override
            public void paint(Graphics g) {
                super.paint(g);
                if(onFocus){
                    g.setColor(new Color(0,255,255,maskOpacity));
                    g.fillRect(5,0,140,40);
                }
            }
            public void displayAnimation(){
                timer =new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        if(maskOpacity>=255){
                            sign=-1;
                        }
                        if(maskOpacity<=0){
                            sign = 1;
                        }
                        maskOpacity+=sign;
                        repaint();
                    }
                },0,2);
            }
            public void ceaseAnimation(){
                timer.cancel();
            }
        }
        private KeyCollector[] keyCollectors;
        SetPlayerKeyMapPanel(int x,int y,int player_code){
            setPreferredSize(new Dimension(360,415));
            setBounds(x,y,360,415);
            setLayout(null);
            setOpaque(false);
            add(new TLabel(0,0,360,50,player_code+" Player Key",ConstructUtil.getSpecificFont(26,ConstructUtil.CAI978)));
            String[] operates={"Move to left","Move to right","Accelerated fall","Clockwise rotate","Anticlockwise rotate","Move to bottom","Hold Block"};
            keyCollectors=new KeyCollector[operates.length];
            for (int i = 0; i < operates.length; i++) {
                add(new TLabel(10,75+50*i,180,40,operates[i],ConstructUtil.getSpecificFont(28,ConstructUtil.ANATEVKA)));
                keyCollectors[i] =new KeyCollector(200,75+50*i,
                        KeyCollector.keyNameMap.get(Configuration.getPlayerKey(player_code, Movement.values()[i])),
                        player_code,
                        Movement.values()[i]);
                add(keyCollectors[i]);
            }
            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    for (int i = 0; i < keyCollectors.length; i++) {
                        if(200<=e.getX()&&e.getX()<=350&&(75+50*i)<=e.getY()&&e.getY()<=(115+50*i)&&e.getButton()==MouseEvent.BUTTON1&&!keyCollectors[i].onFocus){
                            keyCollectors[i].onFocus = true;
                            keyCollectors[i].maskOpacity = 0;
                            keyCollectors[i].displayAnimation();
                        }else{
                            if(keyCollectors[i].onFocus){
                                keyCollectors[i].onFocus = false;
                                keyCollectors[i].maskOpacity = 0;
                                keyCollectors[i].ceaseAnimation();
                                keyCollectors[i].repaint();
                            }

                        }
                    }
                }
            });
        }

        @Override
        public Component add(Component comp) {
            for (int i = 0; i < comp.getKeyListeners().length; i++) {
                addKeyListener(comp.getKeyListeners()[i]);
            }
            for (int i = 0; i < comp.getMouseListeners().length; i++) {
                addMouseListener(comp.getMouseListeners()[i]);
            }
            return super.add(comp);
        }
    }
    private class FreqencySetPanel extends JPanel{
        private TEditField[] tEditFields;
        private int selected_index;
        FreqencySetPanel(int x,int y){
            setPreferredSize(new Dimension(740,160));
            setBounds(x,y,740,160);
            setLayout(null);
            setOpaque(false);
            tEditFields = new TEditField[7];
            selected_index = -1;
            add(new TLabel(0,0,740,60,"Frequency of Blocks\n(Single Play Only)",ConstructUtil.getSpecificFont(26,ConstructUtil.CAI978)));
            for (int i = 0; i < 7; i++) {
                add(new TLabel(11+104*i,80,94,30, BlockType.values()[i+1].name(),ConstructUtil.getSpecificFont(26,ConstructUtil.CAI978)));
                tEditFields[i] = new TEditField(11 + 104 * i, 120, 94, 30, Integer.toString(Configuration.getFreqs(i)), ConstructUtil.getSpecificFont(26, ConstructUtil.CAI978));
                add(tEditFields[i]);
            }
            addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    boolean hasSelected = false;
                    for (int i = 0; i < tEditFields.length; i++) {
                        if((11+i*104)<=e.getX()&&e.getX()<=(105+i*104)&&120<=e.getY()&&e.getY()<=150&&e.getButton()==MouseEvent.BUTTON1&&!tEditFields[i].isOnFocus()){
                            tEditFields[i].setOnFocus(true);
                            selected_index = i;
                            hasSelected = true;
                            repaint();
                        }else{
                            if(tEditFields[i].isOnFocus()){
                                tEditFields[i].setOnFocus(false);
                            }
                        }
                    }
                    if(!hasSelected){
                        selected_index = -1;
                        for (int i = 0; i < 7; i++) {
                            if(!tEditFields[i].getContent().equals("")&&!tEditFields[i].getContent().contains(new String("."))){
                                Configuration.setFreqs(i,Integer.parseInt(tEditFields[i].getContent()));
                            }
                        }
                        repaint();
                    }
                }
            });
        }

        @Override
        public void paint(Graphics g) {
            super.paint(g);
            Graphics2D g2 = (Graphics2D)g;
            g2.setStroke(new BasicStroke(4));
            g2.setColor(Color.CYAN);
            g2.drawRect(2,72,736,87);
            if(selected_index!=-1){
                g2.setStroke(new BasicStroke(4));
                g.setColor(Color.WHITE);
                g.drawRect(tEditFields[selected_index].getX()-3,tEditFields[selected_index].getY()-3,tEditFields[selected_index].getWidth()+6,tEditFields[selected_index].getHeight()+6);
            }
        }

        @Override
        public Component add(Component comp) {
            for (int i = 0; i < comp.getKeyListeners().length; i++) {
                addKeyListener(comp.getKeyListeners()[i]);
            }
            for (int i = 0; i < comp.getMouseListeners().length; i++) {
                addMouseListener(comp.getMouseListeners()[i]);
            }
            return super.add(comp);
        }
    }
    private class SoundSwitchPanel extends JPanel{
        SoundSwitchPanel(int x,int y){
            setPreferredSize(new Dimension(400,90));
            setBounds(x,y,400,90);
            setLayout(null);
            setOpaque(false);
            add(new TLabel(0,0,400,40,"SOUND EFFECT",ConstructUtil.getSpecificFont(26,ConstructUtil.CAI978)));
            add(new TLabel(0,50,120,40,"OFF",ConstructUtil.getSpecificFont(20,ConstructUtil.CAI978)));
            add(new TLabel(280,50,120,40,"ON",ConstructUtil.getSpecificFont(20,ConstructUtil.CAI978)));
            TSwitch tSwitch = new TSwitch(130, 50, 140, 40);
            tSwitch.setOn(Configuration.hasSound);
            tSwitch.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    Configuration.hasSound = tSwitch.isOn();
                }
            });
            add(tSwitch);
        }
        @Override
        public Component add(Component comp) {
            for (int i = 0; i < comp.getKeyListeners().length; i++) {
                addKeyListener(comp.getKeyListeners()[i]);
            }
            for (int i = 0; i < comp.getMouseListeners().length; i++) {
                addMouseListener(comp.getMouseListeners()[i]);
            }
            return super.add(comp);
        }
    }
    private final int WINDOW_WIDTH = 800;
    private final int WINDOW_HEIGHT= 800;
    SettingWindow(){
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setBounds((screenSize.width-WINDOW_WIDTH)/2,(screenSize.height-WINDOW_HEIGHT)/2,WINDOW_WIDTH,WINDOW_HEIGHT);
        setUndecorated(true);
        BackgroundPanel backgroundPanel =  new BackgroundPanel(WINDOW_WIDTH,WINDOW_HEIGHT);
        backgroundPanel.setLayout(null);
        backgroundPanel.add(new SetPlayerKeyMapPanel(30,30,1));
        backgroundPanel.add(new SetPlayerKeyMapPanel(410,30,2));
        backgroundPanel.add(new FreqencySetPanel(30,480));
        backgroundPanel.add(new SoundSwitchPanel(30,670));

        TLabel save = new TLabel(500, 670, 270, 40, "Press F10 SAVE", ConstructUtil.getSpecificFont(16, ConstructUtil.CAI978));
        TLabel exit = new TLabel(500, 720, 270, 40, "Press ESC EXIT", ConstructUtil.getSpecificFont(16, ConstructUtil.CAI978));
        backgroundPanel.add(save);
        backgroundPanel.add(exit);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode()==KeyEvent.VK_ESCAPE){
                    dispose();
                }
                if(e.getKeyCode()==KeyEvent.VK_F10){
                    try {
                        Configuration.saveConfiguration();
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                    dispose();
                }
            }
        });
        add(backgroundPanel);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2 = (Graphics2D)g;
        g2.setStroke(new BasicStroke(10));
        g2.setColor(new Color(9, 145, 244, 100));
        g2.drawRect(5,5,WINDOW_WIDTH-10,WINDOW_HEIGHT-10);
        g2.setColor(Color.CYAN);
        g2.setStroke(new BasicStroke(4));
        g2.drawRect(0,0,WINDOW_WIDTH,WINDOW_HEIGHT);
        g2.drawRect(32,97,355,355);
        g2.drawRect(412,97,355,355);
    }
    @Override
    public Component add(Component comp) {
        for (int i = 0; i < comp.getKeyListeners().length; i++) {
            addKeyListener(comp.getKeyListeners()[i]);
        }
        for (int i = 0; i < comp.getMouseListeners().length; i++) {
            addMouseListener(comp.getMouseListeners()[i]);
        }
        return super.add(comp);
    }

}
