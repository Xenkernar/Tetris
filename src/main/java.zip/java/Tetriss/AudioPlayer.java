package Tetriss;

import javax.sound.sampled.*;
import java.io.DataInputStream;
import java.io.File;
import java.io.IOException;

public class AudioPlayer{
    private static SourceDataLine line;
    private static byte[] audioData;
    private static int length;
    private static BooleanControl muteControl = null;
    private static AudioInputStream audioStream = null;
    static {
        File audioFile = new File("src\\main\\java\\resources\\fixedSoundEffect.wav");
        try {
            audioStream = AudioSystem.getAudioInputStream(audioFile);
            // 获取音频格式
            AudioFormat format = audioStream.getFormat();
            // 获取音频数据的长度
            length = (int) (audioStream.getFrameLength() * format.getFrameSize());
            // 创建一个字节数组来存储音频数据
            audioData = new byte[length];
            // 读取音频数据到字节数组中
            DataInputStream is = new DataInputStream(audioStream);
            is.readFully(audioData);
            // 获取一个SourceDataLine对象并打开
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
            line = (SourceDataLine) AudioSystem.getLine(info);
            line.open(format);

        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }
    public static void play(){
        if(Configuration.hasSound){
            muteControl.setValue(false);
            line.flush();
            line.start();
            line.write(audioData, 0, length);
        }
    }
    public static void prePlay(){
        muteControl = (BooleanControl) line.getControl(BooleanControl.Type.MUTE);
        muteControl.setValue(true);
        line.start();
        line.write(audioData, 0, length);
    }
    public static void close(){
        line.drain();
        line.close();
        try {
            audioStream.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}