package Tetriss;

public class RandomTetris extends OperableTetris{
    private boolean isUneven;
    public RandomTetris(int identifier,boolean isUneven){
        super(identifier);
        this.isUneven = isUneven;
        blocksGenerator = ()-> getRandomType();

    }
    private BlockType getRandomType(){
        return BlockType.values()[isUneven?getUnevenRandom():((int)(Math.random()*7)+1)];
    }
    private int getUnevenRandom(){
        int r =  (int)(Math.random()* Configuration.freq_sum)+1;
        for (int i = 0; i < Configuration.freqs.length; i++) {
            r-= Configuration.freqs[i];
            if(r<=0){
                return i+1;

            }
        }
        return 1;
    }

}
