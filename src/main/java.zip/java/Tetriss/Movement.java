package Tetriss;

public enum Movement {
    LEFT,
    RIGHT,
    DOWN,
    CLOCKWISE,
    ANTICLOCKWISE,
    TO_INFIMUM,
    HOLD
}