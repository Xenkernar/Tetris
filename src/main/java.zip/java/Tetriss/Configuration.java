package Tetriss;


import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.*;
import java.util.Arrays;

public class Configuration {
    private Configuration(){}

    public static final int ROWS = 20;
    public static final int COLS = 10;
    public static final int ROWS_OFFSET = 3;
    public static final int COLS_OFFSET = 1;
    public static final int BLOCK_MAX_LENGTH = 4;
    public static final int BLOCK_MAX_HEIGHT = 2;

    private static final double NEXT_BLOCK_PANEL_RATIO = 147.0/120;
    private static final double HOLD_BLOCK_PANEL_RATIO = 147.0/120;
    private static final double LEVEL_PANEL_RATIO = 295.0/292;
    private static final double SCORE_PANEL_RATIO = 147.0/65;
    private static final double MAINWINDOW_RATIO = 1787.0/1125;
    public static final int BLOCK_SIZE = 20;
    public static final int BORDER_WIDTH = 3;
    public static final int OUTLINE_WIDTH = 2;
    public static final int NEXT_BLOCK_PANEL_WIDTH = 120;
    public static final int NEXT_BLOCK_PANEL_HEIGHT = (int) (NEXT_BLOCK_PANEL_WIDTH / NEXT_BLOCK_PANEL_RATIO + 0.5);
    public static final int HOLD_BLOCK_PANEL_WIDTH = 120;
    public static final int HOLD_BLOCK_PANEL_HEIGHT = (int) (HOLD_BLOCK_PANEL_WIDTH / HOLD_BLOCK_PANEL_RATIO + 0.5);
    public static final int LEVEL_PANEL_WIDTH = 120;
    public static final int LEVEL_PANEL_HEIGHT = (int) (LEVEL_PANEL_WIDTH / LEVEL_PANEL_RATIO + 0.5);
    public static final int SCORE_PANEL_WIDTH = 120;
    public static final int SCORE_PANEL_HEIGHT = (int) (SCORE_PANEL_WIDTH / SCORE_PANEL_RATIO + 0.5);
    public static final int MAINWINDOW_WIDTH = 1000;
    public static final int MAINWINDOW_HEIGHT = (int) (MAINWINDOW_WIDTH / MAINWINDOW_RATIO + 0.5);
    public static final int PANEL_HORIZONTAL_GAP = 10;
    public static final int TETRIS_PANEL_WIDTH = COLS*BLOCK_SIZE+BORDER_WIDTH*2+PANEL_HORIZONTAL_GAP+NEXT_BLOCK_PANEL_WIDTH;
    public static final int TETRIS_PANEL_HEIGHT = ROWS*BLOCK_SIZE+BORDER_WIDTH*2;
    public static final int PANEL_VERTICAL_GAP = (int)((TETRIS_PANEL_HEIGHT-NEXT_BLOCK_PANEL_HEIGHT-HOLD_BLOCK_PANEL_HEIGHT-LEVEL_PANEL_HEIGHT-SCORE_PANEL_HEIGHT)/3.0);




    public static int[] freqs = {3,2,2,1,1,1,2};//I L J Z S O T
    public static int freq_sum = Arrays.stream(freqs).sum();

    public static int getFreqs(int i) {
        return freqs[i];
    }

    public static void setFreqs(int i,int freq) {
        freqs[i] = freq;
    }

    private static int[] player_keySet= {

                    KeyEvent.VK_A,
                    KeyEvent.VK_D,
                    KeyEvent.VK_S,
                    KeyEvent.VK_W,
                    KeyEvent.VK_1,
                    KeyEvent.VK_SPACE,
                    KeyEvent.VK_Q,

                    KeyEvent.VK_LEFT,
                    KeyEvent.VK_RIGHT,
                    KeyEvent.VK_DOWN,
                    KeyEvent.VK_2,
                    KeyEvent.VK_UP,
                    KeyEvent.VK_ENTER,
                    KeyEvent.VK_CONTROL

    };
    public static void setPlayerKey(int player_code, Movement movement, int keyCode){
        player_keySet[(player_code-1)* Movement.values().length+movement.ordinal()] = keyCode;
    }
    public static int getPlayerKey(int player_code, Movement movement){
        return  player_keySet[(player_code-1)* Movement.values().length+movement.ordinal()];
    }

    private static Point[][] blocksPanelCoordinate= {
            {
                    new Point(20,51),
                    new Point(40,51),
                    new Point(60,51),
                    new Point(80,51)
            },
            {
                    new Point(70,41),
                    new Point(30,61),
                    new Point(50,61),
                    new Point(70,61)
            },
            {
                    new Point(30,41),
                    new Point(30,61),
                    new Point(50,61),
                    new Point(70,61)
            },
            {
                    new Point(30,41),
                    new Point(50,41),
                    new Point(50,61),
                    new Point(70,61)
            },
            {
                    new Point(50,41),
                    new Point(70,41),
                    new Point(30,61),
                    new Point(50,61)
            },
            {
                    new Point(40,41),
                    new Point(60,41),
                    new Point(40,61),
                    new Point(60,61)
            },
            {
                    new Point(50,41),
                    new Point(30,61),
                    new Point(50,61),
                    new Point(70,61)
            },
    };
    public static Point[] getBlockPanelCoordinate(BlockType type){
        if(type!= BlockType.NOBLOCK){
            return blocksPanelCoordinate[type.ordinal()-1];
        }
        return null ;
    }

    public static boolean hasSound = true;

    public static void saveConfiguration() throws IOException {
        try {
            FileOutputStream fileOut = new FileOutputStream("src/main/java/resources/config.bin");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(player_keySet);
            out.writeObject(freqs);
            out.writeObject(hasSound);
            out.close();
            fileOut.close();
        } catch (IOException i) {
            i.printStackTrace();
        }
    }
    public static void loadConfiguration(){
        try {
            FileInputStream fileIn = new FileInputStream("src/main/java/resources/config.bin");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            player_keySet = (int[]) in.readObject();
            freqs = (int[]) in.readObject();
            hasSound = (boolean)in.readObject();
            in.close();
            fileIn.close();
        } catch (IOException i) {
            i.printStackTrace();
        } catch (ClassNotFoundException c) {
            System.out.println("Class not found");
            c.printStackTrace();
        }

    }
}
