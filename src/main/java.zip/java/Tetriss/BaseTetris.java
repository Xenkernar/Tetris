package Tetriss;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import static Tetriss.Configuration.*;
import static Window.ConstructUtil.*;

class BaseTetris {
    private BufferedImage[] blockImages;
    private BufferedImage[] numberImages;
    private BufferedImage nextBlockPanelImage;
    private BufferedImage scorePanelImage;
    private BufferedImage holdBlockPanelImage;
    private BufferedImage levelPanelImage;
    protected JPanel TetrisPanel;
    protected BlockType[][] blocksMat;
    protected int[][] movingBlockCoordinate;
    protected HashSet<Point> placementCoordinate;
    protected BlockType movingBlockType;
    protected BlockType nextBlockType;
    protected BlockType holdBlockType;
    protected int score;
    protected int level;
    protected int eliminatedLines;
    protected boolean gameOver;
    protected EliminatePanel eliminatePanel;
    protected NextBlockPanel nextBlockPanel;
    protected ScorePanel scorePanel;
    protected HoldBlockPanel holdBlockPanel;
    protected LevelPanel levelPanel;
    protected BaseTetris() {
        blockImages = new BufferedImage[8];
        numberImages = new BufferedImage[10];
        try {
            blockImages[0] = ImageIO.read( new File("src\\main\\java\\resources\\border.jpg"));
            blockImages[1] = ImageIO.read( new File("src\\main\\java\\resources\\I.jpg"));
            blockImages[2] = ImageIO.read( new File("src\\main\\java\\resources\\L.jpg"));
            blockImages[3] = ImageIO.read( new File("src\\main\\java\\resources\\J.jpg"));
            blockImages[4] = ImageIO.read( new File("src\\main\\java\\resources\\Z.jpg"));
            blockImages[5] = ImageIO.read( new File("src\\main\\java\\resources\\S.jpg"));
            blockImages[6] = ImageIO.read( new File("src\\main\\java\\resources\\O.jpg"));
            blockImages[7] = ImageIO.read( new File("src\\main\\java\\resources\\T.jpg"));
            nextBlockPanelImage = ImageIO.read( new File("src\\main\\java\\resources\\nextBlockPanel.jpg"));
            holdBlockPanelImage = ImageIO.read( new File("src\\main\\java\\resources\\holdBlockPanel.png"));
            levelPanelImage = ImageIO.read( new File("src\\main\\java\\resources\\levelPanel.jpg"));
            scorePanelImage = ImageIO.read(new File("src\\main\\java\\resources\\scorePanel.jpg"));
            for (int i = 0; i < 10; i++) {
                numberImages[i] = ImageIO.read(new File("src\\main\\java\\resources\\"+i+".png"));
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        blocksMat = new BlockType[ROWS+ROWS_OFFSET+1][COLS+COLS_OFFSET+1];
        for (int i = 0; i < ROWS+ROWS_OFFSET+1; i++) {
            for (int j = 0; j < COLS+COLS_OFFSET+1; j++) {
                if(i==0||j==0||i==ROWS+ROWS_OFFSET||j==COLS+COLS_OFFSET){
                    blocksMat[i][j]= BlockType.I;
                }
                else{
                    blocksMat[i][j]= BlockType.NOBLOCK;
                }
            }
        }
        movingBlockCoordinate = new int[BLOCK_MAX_LENGTH][BLOCK_MAX_HEIGHT];
        placementCoordinate = new HashSet<>();
        movingBlockType = BlockType.I;
        nextBlockType = BlockType.I;
        holdBlockType = BlockType.NOBLOCK;
        score = 0;
        level = 1;
        eliminatedLines = 0;
        gameOver = false;
        eliminatePanel = new EliminatePanel();
        nextBlockPanel = new NextBlockPanel();
        scorePanel = new ScorePanel();
        holdBlockPanel = new HoldBlockPanel();
        levelPanel = new LevelPanel();
        TetrisPanel = new JPanel();
        TetrisPanel.setPreferredSize(new Dimension(TETRIS_PANEL_WIDTH,TETRIS_PANEL_HEIGHT));
        TetrisPanel.setLayout(null);
        TetrisPanel.add(eliminatePanel);
        TetrisPanel.add(nextBlockPanel);
        TetrisPanel.add(holdBlockPanel);
        TetrisPanel.add(levelPanel);
        TetrisPanel.add(scorePanel);
        TetrisPanel.setBounds(0,0,TETRIS_PANEL_WIDTH,TETRIS_PANEL_HEIGHT);
        TetrisPanel.setOpaque(false);
    }
    protected class EliminatePanel extends JPanel {
        EliminatePanel(){
            setPreferredSize(new Dimension(BLOCK_SIZE*COLS+BORDER_WIDTH*2,BLOCK_SIZE*ROWS+BORDER_WIDTH*2));
            setBounds(0,0,BLOCK_SIZE*COLS+BORDER_WIDTH*2,BLOCK_SIZE*ROWS+BORDER_WIDTH*2);
        }
        @Override
        public void paint(Graphics g) {
            BasicStroke basicStroke = new BasicStroke(OUTLINE_WIDTH);
            Graphics2D g2 = (Graphics2D)g;
            g2.setStroke(basicStroke);
            g2.setColor(new Color(0,124,217));//边框
            g2.fillRect(0,0,COLS*BLOCK_SIZE+2*BORDER_WIDTH,ROWS*BLOCK_SIZE+2*BORDER_WIDTH);
            for (int i = 0; i < ROWS; i++) {
                for (int j = 0; j < COLS; j++) {
                    g2.drawImage(blockImages[blocksMat[i+ROWS_OFFSET][j+COLS_OFFSET].ordinal()],BORDER_WIDTH+j*BLOCK_SIZE,BORDER_WIDTH+i*BLOCK_SIZE,BLOCK_SIZE,BLOCK_SIZE,null);
                }
            }
            for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                if(movingBlockCoordinate[i][1]>=3){
                    g2.drawImage(blockImages[movingBlockType.ordinal()],BORDER_WIDTH+ (movingBlockCoordinate[i][0]-COLS_OFFSET)*BLOCK_SIZE,BORDER_WIDTH+ (movingBlockCoordinate[i][1]-ROWS_OFFSET)*BLOCK_SIZE,BLOCK_SIZE,BLOCK_SIZE,null);
                }
            }
            g2.setColor(movingBlockType.getColor());
            if(!gameOver){
                for(Point p:placementCoordinate){
                    if(!placementCoordinate.contains(new Point(p.x-1,p.y))){
                        g2.drawLine(
                                BORDER_WIDTH+(p.x-COLS_OFFSET)*BLOCK_SIZE,
                                BORDER_WIDTH+(p.y-ROWS_OFFSET)*BLOCK_SIZE,
                                BORDER_WIDTH+(p.x-COLS_OFFSET)*BLOCK_SIZE,
                                BORDER_WIDTH+(p.y-ROWS_OFFSET)*BLOCK_SIZE+BLOCK_SIZE
                        );
                    }
                    if(!placementCoordinate.contains(new Point(p.x+1,p.y))){
                        g2.drawLine(
                                BORDER_WIDTH+(p.x-COLS_OFFSET)*BLOCK_SIZE+BLOCK_SIZE,
                                BORDER_WIDTH+(p.y-ROWS_OFFSET)*BLOCK_SIZE,
                                BORDER_WIDTH+(p.x-COLS_OFFSET)*BLOCK_SIZE+BLOCK_SIZE,
                                BORDER_WIDTH+(p.y-ROWS_OFFSET)*BLOCK_SIZE+BLOCK_SIZE
                        );
                    }
                    if(!placementCoordinate.contains(new Point(p.x,p.y-1))){
                        g2.drawLine(
                                BORDER_WIDTH+(p.x-COLS_OFFSET)*BLOCK_SIZE,
                                BORDER_WIDTH+(p.y-ROWS_OFFSET)*BLOCK_SIZE,
                                BORDER_WIDTH+(p.x-COLS_OFFSET)*BLOCK_SIZE+BLOCK_SIZE,
                                BORDER_WIDTH+(p.y-ROWS_OFFSET)*BLOCK_SIZE
                        );
                    }
                    if(!placementCoordinate.contains(new Point(p.x,p.y+1))){
                        g2.drawLine(
                                BORDER_WIDTH+(p.x-COLS_OFFSET)*BLOCK_SIZE,
                                BORDER_WIDTH+(p.y-ROWS_OFFSET)*BLOCK_SIZE+BLOCK_SIZE,
                                BORDER_WIDTH+(p.x-COLS_OFFSET)*BLOCK_SIZE+BLOCK_SIZE,
                                BORDER_WIDTH+(p.y-ROWS_OFFSET)*BLOCK_SIZE+BLOCK_SIZE
                        );
                    }
                }
            }
            if(gameOver){
                g.setColor(new Color(72, 72, 187, 168));
                g.fillRect(3,3,200,400);
                g.setFont(getSpecificFont(40,CAI978));
                g.setColor(new Color(0, 136, 238));
                g.drawString("Game",0,200);
                g.drawString("Over",0,240);
            }
        }
    }
    protected class NextBlockPanel extends JPanel{
        NextBlockPanel(){
            setPreferredSize(new Dimension(NEXT_BLOCK_PANEL_WIDTH, NEXT_BLOCK_PANEL_HEIGHT));
            setBounds(BLOCK_SIZE*COLS+BORDER_WIDTH*2+PANEL_HORIZONTAL_GAP,0,NEXT_BLOCK_PANEL_WIDTH,NEXT_BLOCK_PANEL_HEIGHT);
        }
        @Override
        public void paint(Graphics g) {
            BasicStroke basicStroke = new BasicStroke(1);
            Graphics2D g2 = (Graphics2D)g;
            g2.setStroke(basicStroke);
            g2.drawImage(nextBlockPanelImage,0,0,NEXT_BLOCK_PANEL_WIDTH,NEXT_BLOCK_PANEL_HEIGHT,null);
            if(nextBlockType!= BlockType.NOBLOCK){
                for(Point p:getBlockPanelCoordinate(nextBlockType)){
                    g2.drawImage(blockImages[nextBlockType.ordinal()], p.x, p.y, BLOCK_SIZE, BLOCK_SIZE, null);
                }
            }
        }
    }
    protected class ScorePanel extends JPanel{
        ScorePanel(){
            setPreferredSize(new Dimension(SCORE_PANEL_WIDTH, SCORE_PANEL_HEIGHT));
            setBounds(BLOCK_SIZE*COLS+BORDER_WIDTH*2+PANEL_HORIZONTAL_GAP,NEXT_BLOCK_PANEL_HEIGHT+HOLD_BLOCK_PANEL_HEIGHT+LEVEL_PANEL_HEIGHT+3*PANEL_VERTICAL_GAP,SCORE_PANEL_WIDTH,SCORE_PANEL_HEIGHT);
        }
        @Override
        public void paint(Graphics g) {
            BasicStroke basicStroke = new BasicStroke(100);
            Graphics2D g2 = (Graphics2D)g;
            g2.setStroke(basicStroke);
            g2.drawImage(scorePanelImage,0,0,SCORE_PANEL_WIDTH,SCORE_PANEL_HEIGHT,null);
            for (int i = 0; i < Integer.toString(score).length(); i++) {
                g2.drawImage(numberImages[Integer.toString(score).charAt(i)-'0'],5+12*i,29,11,17,null);
            }
        }
    }
    protected class HoldBlockPanel extends JPanel {
        HoldBlockPanel(){
            System.out.println(NEXT_BLOCK_PANEL_HEIGHT+PANEL_VERTICAL_GAP);
            setPreferredSize(new Dimension(HOLD_BLOCK_PANEL_WIDTH, HOLD_BLOCK_PANEL_HEIGHT));
            setBounds(BLOCK_SIZE*COLS+BORDER_WIDTH*2+PANEL_HORIZONTAL_GAP,NEXT_BLOCK_PANEL_HEIGHT+PANEL_VERTICAL_GAP,HOLD_BLOCK_PANEL_WIDTH,HOLD_BLOCK_PANEL_HEIGHT);
        }
        @Override
        public void paint(Graphics g) {
            BasicStroke basicStroke = new BasicStroke(1);
            Graphics2D g2 = (Graphics2D) g;
            g2.setStroke(basicStroke);
            g2.drawImage(holdBlockPanelImage, 0, 0, HOLD_BLOCK_PANEL_WIDTH, HOLD_BLOCK_PANEL_HEIGHT, null);
            if(holdBlockType!= BlockType.NOBLOCK){
                for(Point p:getBlockPanelCoordinate(holdBlockType)){
                    g2.drawImage(blockImages[holdBlockType.ordinal()], p.x, p.y, BLOCK_SIZE, BLOCK_SIZE, null);
                }
            }
        }
    }
    protected class LevelPanel extends JPanel{
        LevelPanel(){
            setPreferredSize(new Dimension(LEVEL_PANEL_WIDTH, LEVEL_PANEL_HEIGHT));
            setBounds(BLOCK_SIZE*COLS+BORDER_WIDTH*2+PANEL_HORIZONTAL_GAP,NEXT_BLOCK_PANEL_HEIGHT+HOLD_BLOCK_PANEL_HEIGHT+2*PANEL_VERTICAL_GAP,LEVEL_PANEL_WIDTH,LEVEL_PANEL_HEIGHT);
        }
        @Override
        public void paint(Graphics g) {
            BasicStroke basicStroke = new BasicStroke(1);
            Graphics2D g2 = (Graphics2D) g;
            g2.setStroke(basicStroke);
            g2.drawImage(levelPanelImage, 0, 0, LEVEL_PANEL_WIDTH, LEVEL_PANEL_HEIGHT, null);
            String levelStr = Integer.toString(level);
            int offset_level = levelStr.length()==1?54:46;
            for (int i = 0; i < levelStr.length(); i++) {
                g2.drawImage(numberImages[levelStr.charAt(i)-'0'],offset_level+16*i,53,14,20,null);
            }
            for (int i = 0; i < Integer.toString(10-eliminatedLines).length(); i++) {
                g2.drawImage(numberImages[Integer.toString(10-eliminatedLines).charAt(i)-'0'],94+8*i,106,7,9,null);
            }
        }
    }
    public JPanel getTetrisPanel(){
        return this.TetrisPanel;
    }
}
