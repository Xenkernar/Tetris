package Tetriss;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Iterator;

import static Tetriss.Configuration.*;
import static Tetriss.Configuration.BLOCK_MAX_HEIGHT;
public class SpecifiedTetris extends OperableTetris{
    private ArrayList<BlockType> blocks;
    private ArrayList<BlockType> opponentBlocks;
    private Iterator<BlockType> iterator;
    private byte[] progress;
    public SpecifiedTetris(int identifier, ArrayList<BlockType> blocks){
        super(identifier);
        this.blocks = blocks;
        iterator = blocks.iterator();
        blocksGenerator = ()-> getSequentialBlock();
        progress = new byte[512];
    }
    private BlockType getSequentialBlock(){
        if(!iterator.hasNext()){
            iterator = blocks.iterator();
        }
        return iterator.next();
    }
    public void sendBlocks(DataOutputStream outTo) throws IOException {
        byte[] bytes = new byte[blocks.size()];
        for (int i = 0; i < bytes.length; i++) {
            bytes[i] = (byte)(blocks.get(i).ordinal());
        }
        outTo.write(bytes);
    }
    public void receiveBlocks(BufferedReader inFrom) throws IOException {
        int b;
        opponentBlocks = new ArrayList<>();
        while ((b=inFrom.read())!=-1){
            opponentBlocks.add(BlockType.values()[b]);
        }
    }
    public void mixBlocks(){
        for (int i = 0; i < blocks.size(); i++) {
            blocks.set(i, BlockType.values()[(blocks.get(i).ordinal()+opponentBlocks.get(i).ordinal()-2)%(BlockType.values().length-1)+1]);
        }
    }

    public void sendProgress(String ip,int port) throws IOException {
        DatagramSocket datagramSocket= new DatagramSocket();
        InetAddress address = InetAddress.getByName(ip);
        getLastProgress();
        DatagramPacket datagramPacket = new DatagramPacket(progress,progress.length,address,port);//打包
        datagramSocket.send(datagramPacket);
        datagramSocket.close();
    }
    private void getLastProgress(){
        int byteNums=0;
        for (int i = 0; i < ROWS+ROWS_OFFSET+1; i++) {
            for (int j = 0; j < COLS+COLS_OFFSET+1; j++) {
                progress[byteNums++] =(byte)(blocksMat[i][j].ordinal());
            }
        }
        for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
            for (int j = 0; j < BLOCK_MAX_HEIGHT; j++) {
                progress[byteNums++] = (byte)movingBlockCoordinate[i][j];
            }
        }
        for(Point p:placementCoordinate){
            progress[byteNums++] = (byte)p.x;
            progress[byteNums++] = (byte)p.y;
        }
        progress[byteNums++] = (byte) (movingBlockType.ordinal());
        progress[byteNums++] = (byte) (nextBlockType.ordinal());
        progress[byteNums++] = (byte) (holdBlockType.ordinal());
        byte[] bytes =  Integer.toString(score).getBytes();
        progress[byteNums++] = (byte)bytes.length;
        for (int i = 0; i < bytes.length; i++) {
            progress[byteNums++] = bytes[i];
        }
        progress[byteNums++] = (byte) level;
        progress[byteNums++] = (byte) eliminatedLines;
        progress[byteNums] = (byte) (gameOver?1:0);
    }
    public void sendGameProgress(String ip,int port){
        Timer timer = new Timer(1, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    getLastProgress();
                    sendProgress(ip,port);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        timer.start();
    }
}
