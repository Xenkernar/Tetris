package Tetriss;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;

import static Tetriss.Configuration.*;
class OperableTetris extends BaseTetris{
    protected int identifier;
    protected LogicController logicController;
    protected BlocksGeneratable blocksGenerator;

    protected class LogicController{
        private int[][] nextBlockSlot;
        private int[][] holdBlockSlot;
        private int eliminatedState;
        private Timer autoDroppingTimer;
        private Timer waitUser;
        private Timer extendWaiting;
        private boolean switchCenterOfRotation;
        private int x,y;//旋转中心
        private HashMap<Integer,Integer> map;
        private int minimum_distance;
        private Movement lastMovementBeforeFixed;
        private boolean canHold;
        private int speed;
        private final int MIN_SPEED;
        private KeyListener keyListener;


        LogicController(){
            map = new HashMap<>();
            lastMovementBeforeFixed= Movement.TO_INFIMUM;
            nextBlockSlot = new int[BLOCK_MAX_LENGTH][BLOCK_MAX_HEIGHT];
            holdBlockSlot = new int[BLOCK_MAX_LENGTH][BLOCK_MAX_HEIGHT];
            eliminatedState=0;
            x=0;
            y=0;
            gameOver=false;
            canHold = true;
            speed = 1000-level*33;
            MIN_SPEED = 33;
            switchCenterOfRotation = false;
            autoDroppingTimer = new Timer(speed, e -> {
                eliminatePanel.repaint();
                if(!canMove(Movement.DOWN)) {
                    doWhenBlockFixed();
                }
                else{
                    moveBlock(Movement.DOWN);
                }
            });
            waitUser = new Timer(1000, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    waitUser.stop();
                    extendWaiting.stop();
                    updateBlocksMat();
                    estimateGameOver();
                    if(gameOver){
                        doWhenGameOver();
                        return;
                    }
                    updateEliminatedState();
                    AudioPlayer.play();
                    canHold = true;
                    nextBlockToBeMoving();
                    generateNextBlock();

                }
            });
            extendWaiting = new Timer(1, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if(canMove(Movement.DOWN)){
                        waitUser.restart();
                    }
                }
            });
            keyListener = new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    for (Movement movement: Movement.values()) {
                        if(e.getKeyCode() == getPlayerKey(identifier,movement)){
                            lastMovementBeforeFixed = movement;
                            if(canMove(movement)) {
                                moveBlock(movement);
                            }
                        }
                    }
                    if(!canMove(Movement.DOWN)) {
                        doWhenBlockFixed();
                    }
                }
            };
            eliminatePanel.addKeyListener(keyListener);
        }
        public void start(){
            generateNextBlock();
            nextBlockToBeMoving();
            generateNextBlock();
            autoDroppingTimer.start();
        }
        private void fillSlot(int[][] slot, BlockType type){
            switch (type){
                case I -> {
                    slot[0][0]=3+COLS_OFFSET;
                    slot[0][1]=2;
                    slot[1][0]=4+COLS_OFFSET;
                    slot[1][1]=2;
                    slot[2][0]=5+COLS_OFFSET;
                    slot[2][1]=2;
                    slot[3][0]=6+COLS_OFFSET;
                    slot[3][1]=2;
                }
                case J -> {
                    slot[0][0]=4+COLS_OFFSET;
                    slot[0][1]=1;
                    slot[1][0]=4+COLS_OFFSET;
                    slot[1][1]=2;
                    slot[2][0]=5+COLS_OFFSET;
                    slot[2][1]=2;
                    slot[3][0]=6+COLS_OFFSET;
                    slot[3][1]=2;
                }
                case L -> {
                    slot[0][0]=6+COLS_OFFSET;
                    slot[0][1]=1;
                    slot[1][0]=4+COLS_OFFSET;
                    slot[1][1]=2;
                    slot[2][0]=5+COLS_OFFSET;
                    slot[2][1]=2;
                    slot[3][0]=6+COLS_OFFSET;
                    slot[3][1]=2;
                }
                case O -> {
                    slot[0][0]=4+COLS_OFFSET;
                    slot[0][1]=2;
                    slot[1][0]=4+COLS_OFFSET;
                    slot[1][1]=1;
                    slot[2][0]=5+COLS_OFFSET;
                    slot[2][1]=2;
                    slot[3][0]=5+COLS_OFFSET;
                    slot[3][1]=1;
                }
                case S -> {
                    slot[0][0]=5+COLS_OFFSET;
                    slot[0][1]=1;
                    slot[1][0]=6+COLS_OFFSET;
                    slot[1][1]=1;
                    slot[2][0]=4+COLS_OFFSET;
                    slot[2][1]=2;
                    slot[3][0]=5+COLS_OFFSET;
                    slot[3][1]=2;
                }
                case T -> {
                    slot[0][0]=5+COLS_OFFSET;
                    slot[0][1]=1;
                    slot[1][0]=4+COLS_OFFSET;
                    slot[1][1]=2;
                    slot[2][0]=5+COLS_OFFSET;
                    slot[2][1]=2;
                    slot[3][0]=6+COLS_OFFSET;
                    slot[3][1]=2;
                }
                case Z -> {
                    slot[0][0]=4+COLS_OFFSET;
                    slot[0][1]=1;
                    slot[1][0]=5+COLS_OFFSET;
                    slot[1][1]=1;
                    slot[2][0]=5+COLS_OFFSET;
                    slot[2][1]=2;
                    slot[3][0]=6+COLS_OFFSET;
                    slot[3][1]=2;
                }
            }
        }
        private void generateNextBlock(){
            nextBlockType = blocksGenerator.getBlock();
            fillSlot(nextBlockSlot,nextBlockType);
            nextBlockPanel.repaint();
        }
        private void nextBlockToBeMoving(){
            for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                for (int j = 0; j < 2; j++) {
                    movingBlockCoordinate[i][j]=nextBlockSlot[i][j];
                }
            }
            movingBlockType = nextBlockType;
            updatePlacementCoordinate();
        }
        private void heldBlockToBeMoving(){
            for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                for (int j = 0; j < 2; j++) {
                    movingBlockCoordinate[i][j]=holdBlockSlot[i][j];
                }
            }
            movingBlockType = holdBlockType;
            updatePlacementCoordinate();
        }
        private void swapMovingAndHeld() {
            if(holdBlockType== BlockType.NOBLOCK){
                fillSlot(holdBlockSlot,movingBlockType);
                holdBlockType = movingBlockType;
                holdBlockPanel.repaint();
                nextBlockToBeMoving();
                generateNextBlock();
            }else {
                BlockType type = movingBlockType;
                heldBlockToBeMoving();
                fillSlot(holdBlockSlot,type);
                holdBlockType = type;
                holdBlockPanel.repaint();
            }
        }
        private void getOutline(Movement movement){
            map.clear();
            switch (movement){
                case DOWN,TO_INFIMUM -> {
                    for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                        map.put(movingBlockCoordinate[i][0],-1);
                    }
                    for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                        if(movingBlockCoordinate[i][1]>map.get(movingBlockCoordinate[i][0])){
                            map.put(movingBlockCoordinate[i][0],movingBlockCoordinate[i][1]);
                        }
                    }

                }
                case LEFT -> {
                    for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                        map.put(movingBlockCoordinate[i][1],COLS+COLS_OFFSET);
                    }
                    for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                        if(movingBlockCoordinate[i][0]<map.get(movingBlockCoordinate[i][1])){
                            map.put(movingBlockCoordinate[i][1],movingBlockCoordinate[i][0]);
                        }
                    }
                }
                case RIGHT -> {
                    for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                        map.put(movingBlockCoordinate[i][1],-1);
                    }
                    for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                        if(movingBlockCoordinate[i][0]>map.get(movingBlockCoordinate[i][1])){
                            map.put(movingBlockCoordinate[i][1],movingBlockCoordinate[i][0]);
                        }
                    }
                }
            }
        }
        private boolean canMove(Movement movement){
            switch (movement){
                case DOWN,TO_INFIMUM -> {
                    getOutline(Movement.DOWN);
                    if(movement== Movement.DOWN){
                        for(int x: map.keySet()){
                            if(blocksMat[map.get(x)+1][x]!= BlockType.NOBLOCK){
                                return false;
                            }
                        }
                        return true;
                    }else{
                        return true;
                    }

                }
                case LEFT -> {
                    getOutline(Movement.LEFT);
                    for(int y: map.keySet()){
                        if(blocksMat[y][map.get(y)-1]!= BlockType.NOBLOCK){
                            return false;
                        }
                    }
                    return true;
                }
                case RIGHT -> {
                    getOutline(Movement.RIGHT);
                    for(int y: map.keySet()){
                        if(blocksMat[y][map.get(y)+1]!= BlockType.NOBLOCK){
                            return false;
                        }
                    }
                    return true;
                }
                case ANTICLOCKWISE,CLOCKWISE -> {
                    x = 0;
                    y = 0;
                    boolean res=true;
                    switch (movingBlockType){
                        case O -> {
                            return false;
                        }
                        case I -> {
                            x = switchCenterOfRotation?movingBlockCoordinate[1][0]:movingBlockCoordinate[2][0];
                            y = switchCenterOfRotation?movingBlockCoordinate[1][1]:movingBlockCoordinate[2][1];
                        }
                        case J,L,Z,T -> {
                            x = movingBlockCoordinate[2][0];
                            y = movingBlockCoordinate[2][1];
                        }
                        case S -> {
                            x = movingBlockCoordinate[0][0];
                            y = movingBlockCoordinate[0][1];
                        }
                    }
                    int x1=0,y1=0;
                    if(movement== Movement.ANTICLOCKWISE){
                        for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                            x1 = x - y + movingBlockCoordinate[i][1];
                            y1 = x + y - movingBlockCoordinate[i][0];
                            if((x1<1||x1>10||y1<1||y1>23)||(!(x1==x&&y1==y)&&blocksMat[y1][x1]!= BlockType.NOBLOCK)){
                                res = false;
                            }
                        }
                    }
                    else {
                        for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                            x1 = y + x - movingBlockCoordinate[i][1];
                            y1 = y - x + movingBlockCoordinate[i][0];
                            if ((x1 < 1 || x1 > 10 || y1 < 1 || y1 > 23) || !(x1 == x && y1 == y) && blocksMat[y1][x1] != BlockType.NOBLOCK) {
                                res = false;
                            }
                        }

                    }
                    return res;

                }
                case HOLD -> {return canHold;}
            }
            return true;
        }
        private void moveBlock(Movement movement){
            switch (movement){
                case DOWN -> {
                    for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                        movingBlockCoordinate[i][1]++;
                    }
                }
                case LEFT -> {
                    for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                        movingBlockCoordinate[i][0]--;
                    }
                }
                case RIGHT -> {
                    for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                        movingBlockCoordinate[i][0]++;
                    }
                }
                case ANTICLOCKWISE,CLOCKWISE -> {
                    int x1=0,y1=0;
                    for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                        if(movement== Movement.ANTICLOCKWISE){
                            x1 = x - y + movingBlockCoordinate[i][1];
                            y1 = x + y - movingBlockCoordinate[i][0];
                        }else{
                            x1 = y + x - movingBlockCoordinate[i][1];
                            y1 = y - x + movingBlockCoordinate[i][0];
                        }
                        movingBlockCoordinate[i][0] = x1;
                        movingBlockCoordinate[i][1] = y1;
                    }
                    switchCenterOfRotation=!switchCenterOfRotation;
                }
                case TO_INFIMUM -> {
                    minimum_distance=Integer.MAX_VALUE;
                    for(int x:map.keySet()){
                        for (int i = map.get(x)+1; i < ROWS+ROWS_OFFSET+1; i++) {
                            if(blocksMat[i][x]!= BlockType.NOBLOCK){
                                minimum_distance=i-map.get(x)<minimum_distance?i-map.get(x):minimum_distance;
                                break;
                            }
                        }
                    }
                    for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                        movingBlockCoordinate[i][1]+=minimum_distance-1;
                    }
                }
                case HOLD -> {
                    swapMovingAndHeld();
                    canHold = false;
                }
            }
            updatePlacementCoordinate();
            eliminatePanel.repaint();
        }
        private void doWhenBlockFixed(){
            if(!gameOver){
                if(lastMovementBeforeFixed== Movement.TO_INFIMUM){
                    waitUser.getActionListeners()[0].actionPerformed(null);
                }
                else{
                    waitUser.start();
                    extendWaiting.start();
                }
            }
        }
        private void doWhenGameOver(){
            System.out.println("1");
            autoDroppingTimer.stop();
            extendWaiting.stop();
            waitUser.stop();
        }
        private void estimateGameOver(){
            int ceiling=24;
            for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                ceiling = movingBlockCoordinate[i][1]<ceiling?movingBlockCoordinate[i][1]:ceiling;
                if(ceiling<3){
                    gameOver = true;
                    return;
                }
            }
        }
        private void updateBlocksMat(){
            for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                blocksMat[movingBlockCoordinate[i][1]][movingBlockCoordinate[i][0]]=movingBlockType;
            }
        }
        private void updateEliminatedState(){//根据当前方块矩阵的状态判断消除情况，并更新方块矩阵
            eliminatedState=0;
            boolean rowEliminated=true;
            int lastEliminatedRow=0;
            for (int i = 0; i < ROWS; i++) {
                rowEliminated=true;
                for (int j = 0; j < COLS; j++) {
                    if(blocksMat[i+ROWS_OFFSET][j+COLS_OFFSET]== BlockType.NOBLOCK){
                        rowEliminated=false;
                        break;
                    }
                }
                if(rowEliminated){
                    eliminatedState+=1;
                    lastEliminatedRow=i+ROWS_OFFSET;
                }
            }
            score+=50*level;
            scorePanel.repaint();
            if(eliminatedState==0){
                return;
            }
            switch (eliminatedState){
                case 1->score+=100*Math.pow(level,1.1);
                case 2->score+=300*Math.pow(level,1.2);
                case 3->score+=600*Math.pow(level,1.3);
                case 4->score+=1200*Math.pow(level,1.5);
            }
            eliminatedLines+=eliminatedState;
            if(eliminatedLines>=10){
                eliminatedLines-=10;
                level+=1;
                speed-=(level*33);
                if(speed<=MIN_SPEED){
                    speed = MIN_SPEED;
                }
                autoDroppingTimer.setDelay(speed);
            }
            levelPanel.repaint();
            scorePanel.repaint();
            for (int i = lastEliminatedRow-eliminatedState; i >=ROWS_OFFSET; i--) {
                for (int j = 0; j < COLS; j++) {
                    blocksMat[i+eliminatedState][j+COLS_OFFSET]=blocksMat[i][j+COLS_OFFSET];
                }
            }
            for (int i = 0; i < eliminatedState; i++) {
                for (int j = 0; j < COLS; j++) {
                    blocksMat[i+ROWS_OFFSET][j+COLS_OFFSET]= BlockType.NOBLOCK;
                }
            }

        }
        private void updatePlacementCoordinate(){
            getOutline(Movement.DOWN);
            placementCoordinate.clear();
            minimum_distance=Integer.MAX_VALUE;
            for(int x:map.keySet()){
                for (int i = map.get(x)+1; i < ROWS+ROWS_OFFSET+1; i++) {
                    if(blocksMat[i][x]!= BlockType.NOBLOCK){
                        minimum_distance=i-map.get(x)<minimum_distance?i-map.get(x):minimum_distance;
                        break;
                    }
                }
            }

            for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
                placementCoordinate.add(new Point(movingBlockCoordinate[i][0],movingBlockCoordinate[i][1]+minimum_distance-1));
            }
        }
    }

    protected OperableTetris(int identifier){
        this.identifier = identifier;
        logicController = new LogicController();
    }
    public void start(){
        logicController.start();
    }
    public KeyListener getKeyListener(){
        return eliminatePanel.getKeyListeners()[0];
    }
    public int getScore(){
        return score;
    }
    public boolean isOver(){
        return gameOver;
    }
    public void pauseGame(){
        logicController.autoDroppingTimer.stop();
        logicController.extendWaiting.stop();
        logicController.waitUser.stop();
    }
    public void continueGame(){
        logicController.autoDroppingTimer.start();
    }

}
