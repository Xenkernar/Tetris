package Tetriss;
@FunctionalInterface
interface BlocksGeneratable {
    public abstract BlockType getBlock();
}
