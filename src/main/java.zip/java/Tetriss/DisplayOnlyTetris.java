package Tetriss;


import java.awt.*;
import java.io.IOException;
import java.net.*;
import java.util.Timer;
import java.util.TimerTask;

import static Tetriss.Configuration.*;
public class DisplayOnlyTetris extends BaseTetris{
    private byte[] progress;
    private int port;
    private DatagramSocket datagramSocket;
    private DatagramPacket datagramPacket;
    public DisplayOnlyTetris(int port) throws SocketException {
        this.port = port;
        progress = new byte[512];
        datagramSocket = new DatagramSocket(port);
        datagramPacket = new DatagramPacket(progress,progress.length);
    }
    public void receiveProgress() throws IOException {
        datagramSocket.receive(datagramPacket);
        parseProgress();
        eliminatePanel.repaint();
        nextBlockPanel.repaint();
        holdBlockPanel.repaint();
        levelPanel.repaint();
        scorePanel.repaint();
    }
    private void parseProgress(){
        int byteNums=0;
        for (int i = 0; i < ROWS+ROWS_OFFSET+1; i++) {
            for (int j = 0; j < COLS+COLS_OFFSET+1; j++) {
                blocksMat[i][j] = BlockType.values()[progress[byteNums++]];
            }
        }
        for (int i = 0; i < BLOCK_MAX_LENGTH; i++) {
            for (int j = 0; j < BLOCK_MAX_HEIGHT; j++) {
                movingBlockCoordinate[i][j] = progress[byteNums++];
            }
        }
        placementCoordinate.clear();
        for (int i = 0; i < 4; i++) {
            placementCoordinate.add(new Point(progress[byteNums++],progress[byteNums++]));
        }
        movingBlockType= BlockType.values()[progress[byteNums++]];
        nextBlockType= BlockType.values()[progress[byteNums++]];
        holdBlockType= BlockType.values()[progress[byteNums++]];
        byte len = progress[byteNums++];
        score = Integer.parseInt(new String(progress,byteNums,len));
        byteNums+=len;
        level=progress[byteNums++];
        eliminatedLines=progress[byteNums++];
        gameOver = progress[byteNums] == 1;
    }
    public void reveiveGameProgress(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                java.util.Timer timer = new Timer();
                timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        try {
                            receiveProgress();
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }, 0, 1);
            }
        }).start();
    }

}
